from setuptools import setup, find_packages
setup(
    name="Python_Adafruit_GFX",
    version="0.1",
    packages=find_packages(),
)